#!/bin/bash
# Build first: Android Studio > Build > Build App Bundle(s) / APK(s) > Build APK(s)
# Usage: ./install.sh TV_IP
set -e
IP=${1:?usage: ./install.sh TV_IP}
S=$IP:5555
APK=app/build/outputs/apk/debug/app-debug.apk
[ -f "$APK" ] || { echo "APK not found. Build it in Android Studio first."; exit 1; }
adb connect "$S"
mkdir -p backup
adb -s "$S" shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME > backup/home_before.txt
adb -s "$S" shell cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME > backup/home_all_before.txt
adb -s "$S" install -r "$APK"      # on Android 14, if this hangs, accept the prompt on the TV
adb -s "$S" shell cmd package set-home-activity local.tvhome/.MainActivity
echo
echo "Installed. NOW press Home from inside another app (e.g. YouTube), then run:"
echo "  adb -s $S shell dumpsys activity activities | grep mFocusedApp"
echo "It must show local.tvhome. If it still shows launcherx or setupwraith, run ./launcher_restore.sh $IP"
echo "Do NOT disable the stock Google TV Home until this works."
