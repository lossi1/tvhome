# TvHome — μικρός launcher για Android/Google TV

Μαύρο φόντο, dock με αγαπημένες εφαρμογές, πλέγμα με τις υπόλοιπες, ρολόι/ημερομηνία πάνω αριστερά,
κουμπιά Είσοδοι / Wi-Fi / Ρυθμίσεις πάνω δεξιά. Χωρίς δίκτυο, blur ή βίντεο. **Δεν έχει δοκιμαστεί σε πραγματική
τηλεόραση** — το μέγεθος και οι αποστάσεις μπορεί να θέλουν ρύθμιση (η οθόνη σου είναι 1366×768).

## Δεν υπάρχουν ακόμα
Φωτεινό "glass" highlight που κινείται από κελί σε κελί, χρώμα glow από το banner, όνομα δικτύου στο Wi-Fi,
απομνημόνευση του τελευταίου κελιού, γραμματοσειρά Outfit. Η εφαρμογή χρησιμοποιεί τις γραμματοσειρές συστήματος.

## Χτίσιμο (χρειάζεται υπολογιστής)
1. Εγκατέστησε το Android Studio. Άνοιξε αυτόν τον φάκελο (File > Open). Άσε το Studio να κατεβάσει Gradle και SDK 34.
   Αν προτείνει αναβάθμιση του Android Gradle Plugin, δέξου.
2. Build > Build App Bundle(s) / APK(s) > Build APK(s). Το αρχείο βγαίνει στο
   `app/build/outputs/apk/debug/app-debug.apk`.

## Εγκατάσταση
Στην τηλεόραση ενεργοποίησε το ADB debugging, και μετά:
```
./install.sh IP_ΤΗΣ_ΤΗΛΕΟΡΑΣΗΣ
```
Πάτα Home **μέσα από μια εφαρμογή** (π.χ. YouTube). Έλεγξε με:
```
adb -s IP:5555 shell dumpsys activity activities | grep mFocusedApp
```
Πρέπει να γράφει `local.tvhome`. Αν δείχνει `launcherx` ή `setupwraith`, το set-home-activity δεν έπιασε:
τρέξε `./launcher_restore.sh IP`. **Μην απενεργοποιήσεις το Google TV Home πριν δουλέψει.**

## Αλλαγές
- Σειρά dock και εφαρμογές: `app/src/main/res/values/config.xml` → `dock_apps` (ονόματα πακέτων). `dock_slots` = θέσεις (4–7).
  Πακέτα που λείπουν παραλείπονται και το dock συμπληρώνεται με άλλες εφαρμογές.
- Ταπετσαρίες: βάλε εικόνες .jpg/.png/.webp στο `app/src/main/assets/wallpapers/` και χτίσε ξανά.
  `wallpaper_minutes` = κάθε πόσα λεπτά αλλάζουν (0 = κλειστό). Χωρίς εικόνες, το φόντο μένει μαύρο.
  Προτίμησε εικόνες γύρω στα 1366×768: η τηλεόραση έχει ~1 GB RAM.
- Για να βρεις το πακέτο μιας εφαρμογής: `adb shell pm list packages | grep όνομα`.

## Επαναφορά
- Launcher: `./launcher_restore.sh IP` (επαναφέρει το Google TV Home και αφαιρεί αυτό το app). Μετά επανεκκίνηση.
- Εφαρμογές που απενεργοποιήθηκαν από το debloat: `bash tvd.sh restore` στο Termux, ή Ρυθμίσεις → Εφαρμογές →
  Εμφάνιση όλων → διάλεξε την εφαρμογή → Ενεργοποίηση.

## Όταν τελειώσεις: κλείσε το ADB
Επιλογές προγραμματιστή → κλείσε USB debugging και Network debugging → Revoke USB debugging authorisations →
επανεκκίνηση. Έλεγξε ότι το `adb connect IP:5555` δίνει "Connection refused".
