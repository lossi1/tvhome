package local.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Minimal Apple-TV-style home screen: dock + grid, no network, no blur, no video. */
public class MainActivity extends Activity {

    static class App { String pkg; String label; Drawable icon; }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private RecyclerView dock, grid;
    private TextView dockName, greeting, pillInputs, pillWifi, pillSettings;
    private ImageView wall;
    private int cols, slots, wallMinutes, wallIdx;
    private final List<String> wallFiles = new ArrayList<>();
    private boolean firstLoad = true;

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { loadApps(); }
    };

    private final Runnable wallTick = new Runnable() {
        @Override public void run() {
            showWall(wallFiles.get(wallIdx++ % wallFiles.size()));
            handler.postDelayed(this, wallMinutes * 60000L);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        cols = getResources().getInteger(R.integer.columns);
        slots = getResources().getInteger(R.integer.dock_slots);
        wallMinutes = getResources().getInteger(R.integer.wallpaper_minutes);
        wall = findViewById(R.id.wall);
        greeting = findViewById(R.id.greeting);
        dockName = findViewById(R.id.dock_name);
        dock = findViewById(R.id.dock);
        grid = findViewById(R.id.grid);
        pillInputs = findViewById(R.id.pill_inputs);
        pillWifi = findViewById(R.id.pill_wifi);
        pillSettings = findViewById(R.id.pill_settings);
        grid.setItemAnimator(null);
        dock.setItemAnimator(null);
        wirePills();

        try {
            String[] f = getAssets().list("wallpapers");
            if (f != null) for (String s : f) {
                String l = s.toLowerCase();
                if (l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp")) wallFiles.add(s);
            }
        } catch (Exception ignored) { }

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        loadApps();
    }

    @Override protected void onResume() {
        super.onResume();
        int hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        greeting.setText(hr < 12 ? R.string.g_morning : hr < 18 ? R.string.g_afternoon : R.string.g_evening);
        if (!wallFiles.isEmpty() && wallMinutes > 0) handler.post(wallTick);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacksAndMessages(null);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) { }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);          // Home pressed while we are already on screen
        grid.scrollToPosition(0);
        focusDock();
    }

    // ---- focus helpers -------------------------------------------------------------------
    private void focusDock() {
        if (dock.getChildCount() > 0) dock.getChildAt(0).requestFocus(); else dock.requestFocus();
    }
    private void focusGrid() {
        if (grid.getChildCount() > 0) grid.getChildAt(0).requestFocus();
    }

    private void wirePills() {
        pillInputs.setOnClickListener(v -> showInputs());
        pillWifi.setOnClickListener(v -> startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        pillSettings.setOnClickListener(v -> startSafe(new Intent(Settings.ACTION_SETTINGS)));
        // Up is swallowed; Down goes to the dock; the left end / right end do not fall through.
        pillInputs.setOnKeyListener((v, k, e) -> pillKey(k, e, true, false));
        pillWifi.setOnKeyListener((v, k, e) -> pillKey(k, e, false, false));
        pillSettings.setOnKeyListener((v, k, e) -> pillKey(k, e, false, true));
    }

    private boolean pillKey(int k, KeyEvent e, boolean first, boolean last) {
        if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
        if (k == KeyEvent.KEYCODE_DPAD_UP) return true;
        if (k == KeyEvent.KEYCODE_DPAD_DOWN) { focusDock(); return true; }
        if (k == KeyEvent.KEYCODE_DPAD_LEFT && first) return true;
        if (k == KeyEvent.KEYCODE_DPAD_RIGHT && last) return true;
        return false;
    }

    // ---- apps ----------------------------------------------------------------------------
    private void loadApps() {
        PackageManager pm = getPackageManager();
        Map<String, App> map = new LinkedHashMap<>();
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || map.containsKey(p)) continue;
                App a = new App();
                a.pkg = p;
                a.label = String.valueOf(ri.loadLabel(pm));
                a.icon = ri.loadIcon(pm);
                map.put(p, a);
            }
        }
        List<App> dockApps = new ArrayList<>();
        for (String p : getResources().getStringArray(R.array.dock_apps)) {
            if (dockApps.size() >= slots) break;
            App a = map.remove(p);
            if (a != null) dockApps.add(a);
        }
        List<App> rest = new ArrayList<>(map.values());
        Collections.sort(rest, new Comparator<App>() {
            @Override public int compare(App x, App y) { return x.label.compareToIgnoreCase(y.label); }
        });
        while (dockApps.size() < slots && !rest.isEmpty()) dockApps.add(rest.remove(0));

        dock.setLayoutManager(new GridLayoutManager(this, Math.max(1, dockApps.size())));
        grid.setLayoutManager(new GridLayoutManager(this, cols));
        dock.setAdapter(new Adapter(dockApps, true, dockApps.size()));
        grid.setAdapter(new Adapter(rest, false, cols));
        if (!dockApps.isEmpty()) dockName.setText(dockApps.get(0).label);
        if (firstLoad) { firstLoad = false; dock.post(this::focusDock); }
    }

    private void launch(String pkg) {
        PackageManager pm = getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i != null) startSafe(i);
    }

    private void startSafe(Intent i) {
        try { startActivity(i); } catch (Exception e) { Toast.makeText(this, e.getClass().getSimpleName(), Toast.LENGTH_SHORT).show(); }
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        private final List<App> items;
        private final boolean isDock;
        private final int span;
        Adapter(List<App> items, boolean isDock, int span) { this.items = items; this.isDock = isDock; this.span = Math.max(1, span); }

        class VH extends RecyclerView.ViewHolder {
            final ImageView icon; final TextView name;
            VH(View v) { super(v); icon = v.findViewById(R.id.icon); name = v.findViewById(R.id.name); }
        }

        @Override public VH onCreateViewHolder(ViewGroup p, int t) {
            return new VH(getLayoutInflater().inflate(R.layout.item_app, p, false));
        }

        @Override public void onBindViewHolder(final VH h, int pos) {
            final App a = items.get(pos);
            h.icon.setImageDrawable(a.icon);
            h.name.setText(a.label);
            h.name.setVisibility(isDock ? View.GONE : View.INVISIBLE);
            h.itemView.setOnClickListener(v -> launch(a.pkg));
            h.itemView.setOnFocusChangeListener((v, f) -> {
                v.animate().scaleX(f ? 1.12f : 1f).scaleY(f ? 1.12f : 1f).setDuration(120).start();
                if (isDock) { if (f) dockName.setText(a.label); }
                else h.name.setVisibility(f ? View.VISIBLE : View.INVISIBLE);
            });
            h.itemView.setOnKeyListener((v, k, e) -> {
                if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
                int p = h.getAdapterPosition();
                if (isDock) {
                    if (k == KeyEvent.KEYCODE_DPAD_UP) { pillWifi.requestFocus(); return true; }
                    if (k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); return true; }
                } else {
                    if (k == KeyEvent.KEYCODE_DPAD_UP && p < span) { focusDock(); return true; }
                    if (k == KeyEvent.KEYCODE_DPAD_DOWN && p + span >= items.size()) return true;
                }
                return false;
            });
        }

        @Override public int getItemCount() { return items.size(); }
    }

    // ---- inputs (HDMI / AV / Live TV) ----------------------------------------------------
    private void showInputs() {
        TvInputManager tim = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
        final List<TvInputInfo> list = tim == null ? new ArrayList<TvInputInfo>() : tim.getTvInputList();
        if (list.isEmpty()) { Toast.makeText(this, R.string.inputs_none, Toast.LENGTH_SHORT).show(); return; }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) {
            TvInputInfo info = list.get(i);
            CharSequence c = info.loadCustomLabel(this);
            names[i] = String.valueOf(c != null && c.length() > 0 ? c : info.loadLabel(this));
        }
        new AlertDialog.Builder(this).setTitle(R.string.inputs_title)
                .setItems(names, (d, w) -> openInput(list.get(w))).show();
    }

    private void openInput(TvInputInfo info) {
        try {
            Uri u = info.isPassthroughInput()
                    ? TvContract.buildChannelUriForPassthroughInput(info.getId())
                    : TvContract.Channels.CONTENT_URI;
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) {
            Toast.makeText(this, R.string.inputs_fail, Toast.LENGTH_SHORT).show();
        }
    }

    // ---- wallpapers (optional, from assets/wallpapers) -----------------------------------
    private void showWall(String name) {
        try {
            String path = "wallpapers/" + name;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getAssets().open(path)) { BitmapFactory.decodeStream(in, null, o); }
            int s = 1;
            while (o.outWidth / (s * 2) >= 1366) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bmp;
            try (InputStream in = getAssets().open(path)) { bmp = BitmapFactory.decodeStream(in, null, o2); }
            if (bmp == null) return;
            wall.setImageBitmap(bmp);
            wall.setAlpha(0f);
            wall.animate().alpha(1f).setDuration(800).start();
        } catch (Exception ignored) { }
    }
}
