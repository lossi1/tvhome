#!/bin/bash
# Puts the stock Google TV Home back. Usage: ./launcher_restore.sh TV_IP
IP=${1:?usage: ./launcher_restore.sh TV_IP}
S=$IP:5555
adb connect "$S"
adb -s "$S" shell pm enable com.google.android.apps.tv.launcherx
adb -s "$S" shell cmd package set-home-activity com.google.android.apps.tv.launcherx/.home.HomeActivity
adb -s "$S" shell pm uninstall local.tvhome
echo "Stock Home restored. Reboot the TV."
